package com.vinsguru.movie.dto;

public record ActorDto(Integer id,
                       String name) {
}
