package com.vinsguru.actor.dto;

public record ActorDto(Integer id,
                       String name) {
}
